~/SIMrecon_tiff/radialft RAWbeadSI_zp1um_60b_cfp05_20ms_ch0_stack0000_488nm_0000000msec.tif otf_test.tif -xyres 0.104 -zres 0.19 -nphases 5
